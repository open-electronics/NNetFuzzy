/**************************************************************************************

Neural Networks Fuzzy library. It can works also on Arduino platform.
This version works as Fuzzy System.
If it runs on Arduino you have to uncomment "#define ARDUINONNfuzzy"
By contrast, if library is used on computer, you have to comment this define statement.

You can use Neural Network of 3 layer.
Each layer can have any number of nodes.
Layer 0 is the input layer (just to collect input values); transfer function is linear.
Layer 1 is the hidden layer. Each node summarize inputs weighted by input links.
For this layer you can chose from different transfer functions.
Layer 2 is the output layer. You can collect result value from this layer.
Also this layer summarize weighted hidden values.
You can chose transfer function from different model.
Transfer functions provided in this version:
- NodeLin  (linear function; fixed for layer 0)(not used)
- NodeFuzzy (for hidden layer)(mandatory for hidden layer) (each node : one fuzzy set)
- NodeDeFuz (defuzzyng function for output layer) (Sugeno mode)
- NodeDFTnh (alternative defuzzing function soft limited -1 to 1)
- NodeDFSig (alternative defuzzing function soft limited 0 to 1)

Nerual Network can be defined with random weight for training phase or
can be defined with correct value for use it.
- Random definition:   NNfuzzy(int L0n,int L1n,const char* L1Type,int L2n,const char* L2Type);
- complete definition: NNfuzzy(char netdef[]); (by definition string)
                       NNfuzzy(const char* filename);  (by file; not for Arduino)
                       save(const char* filename);  (save on file; not for Arduino)

Examples:
Definition of a random net of 2 input nodes, 2 hidden NodeTanh and one NodeLin for output layer
   NNFuzzy net(2,4,"NodeFuzzy",1,"NodeDeFuz");

Creation of similar neural network but with exact weight values
   NNFuzzy net(char netdef[]);

   where netdef string is defined as:
   char* netdef=
"L0 2 "
"L1 4 NodeFuzzy "
"FCT0 0.3802 0.8168 " /center of node 0 (center of fuzzy set 0)
"FCT1 0.3432 0.1120 "                                        1
"FCT2 0.1953 0.1037 "                                        2
"FCT3 0.2330 0.6304 "                                        3
"FWA0 0.7900 1.7131 " /left membership (linear) function of fuzzy set 0
"FWA1 0.7612 1.7884 "
"FWA2 0.7210 0.7488 "
"FWA3 1.2975 1.3568 "
"FWB0 1.3775 1.2198 " /right membership (linear) function of fuzzy set 0
"FWB1 1.5658 1.2703 "
"FWB2 1.9828 1.1685 "
"FWB3 1.4026 1.4107 "
"L2 1 NodeDeFuz "
"OLW0 -0.0098 -0.0296 -0.0886 0.0215 "
;
NB. Always separate token with spaces!

********************************************************************************************/

#ifndef NNETFUZZY_H
#define NNETFUZZY_H
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define RA -0.1
#define RB +0.1

#define DEFEPS 0.1
#define NOINP INFINITY
#define SELFC 0.01   //Percent of self organize fuzzy rules by input


void setLearnCoeff(float eps);
void setAutoLrnCoeff(bool yn);
void setAutoLrnCoeff(bool yn,float w);
void setRatioSelfBack(float r);
float getRatioSelfBack();

#define ARDUINONNFuzzy   //uncomment if used on ARDUINO or comment if not


class NNfuzzy
{
    public:

/** Definition of random fuzzy NNFuzzy(NNFuzzy to train):
    L0n: number of nodes of layer 0
    L1n: number of nodes of layer 1
    L2n: number of nodes of layer 2
*/
        NNfuzzy(int L0n,int L1n,int L2n);

/** Definition of random fuzzy nnet with output limited
    if limit=1 limited from 0 to 1
    if limit=2 limited from -1 to 1
*/
        NNfuzzy(int L0n,int L1n,int L2n,int limit);

/** Creation of a NNFuzzy described in netdef string */
        NNfuzzy(char netdef[]);

#ifndef ARDUINONNET
/** Creation of a NNFuzzy described in file with name filename (not Arduino)*/
        NNfuzzy(const char* filename);
#endif // NOARDUINO

        virtual ~NNfuzzy();

/** Basic exploitation function.
    inp array has to contain input values and out array is the buffer that collect result
    (diminp: input array size; dimout: output array size).
    If you want to leave some inp values indeterminate you have to put NOINP (not 0 !)
    into these inp variables. In this case fuzzy output values are computed using a sort of
    associative memory. Es.: inp[1]=NOINP */
        void forw(float inp[],int diminp,float out[],int dimout);

/** Training function.
    train array is the forced output supplied by user.
    Function returns the squared mean error */
        float learn(float inp[],int diminp,float train[],int dimtrain);

/** Print NNFuzzy structure*/
        void print();

#ifndef ARDUINONNET
/** Save NNFuzzy structure on file*/
        void save(char* filename);
        void savexardu(char* filename);
#endif // NOARDUINO

/* Utilities */
        void getHiddenOut(float out[],int dimout);
        void getWeightsL1fromL0(int nodeL1,float w[],int dimw);
        void getWeightsL2fromL1(int nodeL2,float w[],int dimw);
        void setWeightsL2fromL1(int nodeL2,float w[],int dimw);

        void getFuzzyCtr(int node,float c[],int dimc);
        void getFuzzyWa(int node,float wa[],int dimwa);
        void getFuzzyWb(int node,float wb[],int dimwb);

        float getFuzzyCtr(int node,int from);
        float getFuzzyWa(int node,int from);
        float getFuzzyWb(int node,int from);
        float getWeightOut(int node,int from);
        int getNodesNum(int layer);

    protected:

    private:
        int lay0n;
        int lay1n;
        int lay2n;
        struct Lhid
        {
           float buff;
           float out;
           float err;
           float* wga;
           float* wgb;
           float* ctr;
        };
        struct Lout
        {
           float buff;
           float out;
           float* wgt;
        };
        Lhid*  hidn;
        Lout*  outn;

        float (*frw1)(float act);
        float (*frw2)(float act);
        float (*learn1)(float out);
        float (*learn2)(float out);

        void decodeType1(const char* ty);
        void decodeType2(const char* ty);
        char ty1[20];
        char ty2[20];

        float best;
        int ibest;

        void  init(int L0n,int L1n,const char* L1Type,int L2n,const char* L2Type);



#ifndef ARDUINONNET
        void outdef(FILE* fp,bool ardu);
#endif // ARDUINO

        int readval(char* token);
        int decode(char* token);
        void getToken(char* netdef,char token[],int lentok, int* next);

        int cnti,cntj;
        int state;

};

float Fuzzyfrw(float x);
float Fuzzylrn(float y);

float DeFuzzyfrw(float x);
float DeFuzzylrn(float y);


#endif // NNETFUZZY_H
