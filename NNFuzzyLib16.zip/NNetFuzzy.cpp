#include "NNetFuzzy.h"

float fmax(float a,float b){return a>b?a:b ;}
float fmin(float a,float b){return a<b?a:b ;}
int imax(int a,int b){return a>b?a:b ;}
int imin(int a,int b){return a<b?a:b ;}

float rnd(float a, float b)
{
    float r=rand();
    r=r/RAND_MAX;r= r * (b-a);r=r+a;
    return r;
}


float EPS=DEFEPS;
bool AUTOEPS=false;
float WAUTOEPS=1;
float selfc=SELFC;

void setLearnCoeff(float eps){EPS=eps;}
void setAutoLrnCoeff(bool yn){AUTOEPS=yn;}
void setAutoLrnCoeff(bool yn,float w){AUTOEPS=yn;WAUTOEPS=w;}
void setRatioSelfBack(float r){double i;selfc=modf(r,&i);}
float getRatioSelfBack(){return selfc;}

/**********************************************************************/
/*********** Only Fuzzy Version ****************/

NNfuzzy::NNfuzzy(int L0n,int L1n,int L2n)
{init(L0n,L1n,"NodeFuzzy",L2n,"NodeDeFuz");}

NNfuzzy::NNfuzzy(int L0n,int L1n,int L2n,int limit)
{
    if (limit==0) {init(L0n,L1n,"NodeFuzzy",L2n,"NodeDeFuz");return;}
    if (limit==1) {init(L0n,L1n,"NodeFuzzy",L2n,"NodeDFSig");return;}
    if (limit==2) {init(L0n,L1n,"NodeFuzzy",L2n,"NodeDFTnh");return;}
}


void NNfuzzy::init(int L0n,int L1n,const char* L1Type,int L2n,const char* L2Type)
{
   lay0n=L0n;
   lay1n=L1n;
   lay2n=L2n;
   decodeType1(L1Type);
   decodeType2(L2Type);
   hidn=new Lhid[lay1n];
   outn=new Lout[lay2n];

   for (int i=0;i<lay1n;i++)
   {
       Lhid* hid=&hidn[i];
       hid->buff=0;
       hid->err=0;
       hid->out=0;
       hid->wga=new float[lay0n];
       hid->wgb=new float[lay0n];
       hid->ctr=new float[lay0n];
       for (int j=0;j<lay0n;j++){hid->wga[j]=rnd(0.5,2);}
       for (int j=0;j<lay0n;j++){hid->wgb[j]=rnd(0.5,2);}
       for (int j=0;j<lay0n;j++){hid->ctr[j]=rnd(0.1,0.9);}
   }

   for (int i=0;i<lay2n;i++)
   {
       Lout* out=&outn[i];
       out->buff=0;
       out->out=0;
       out->wgt=new float[lay1n];
       for (int j=0;j<lay1n;j++){out->wgt[j]=rnd(RA,RB);}
   }
}

NNfuzzy::~NNfuzzy()
{
    /*
    printf("Eliminazione...\n");
    for (int i=0;i<lay1n;i++){delete[] hidn[i].ctr;delete[] hidn[i].wga;delete[] hidn[i].wgb;}
 for (int i=0;i<lay2n;i++){delete[] outn[i].wgt;}
 delete[] hidn;delete[] outn;

 printf("Eliminato!\n");
 */
 }


void NNfuzzy::forw(float inp[],int diminp,float out[],int dimout)
{
   int din=imin(diminp,lay0n);
   int dou=imin(diminp,lay2n);

   float c,a,b,x,d2;
   best=0;
    for (int i=0;i<lay1n;i++)
    {
       d2=0;
       float act=1,actk;
       for (int k=0;k<lay0n;k++)
       {
           x=inp[k];
           if (x==INFINITY) continue;               //jump if input is not provided
           c=hidn[i].ctr[k];
           a=hidn[i].wga[k];
           b=hidn[i].wgb[k];
           if (x<c) actk=fmax(0,1-a*(c-x));         // __/
           else actk=fmax(0,1-b*(x-c));             //     \__
           if (actk<act) {act=actk;hidn[i].buff=k;} //min value of k (fuzzy AND) ; save k min
           d2=d2+(x-c)*(x-c);                       //quadratic distance
       }
       hidn[i].out=(*frw1)(act);                    //fuzzy activation
       hidn[i].err=0;
       if (i==0) {best=d2;ibest=0;}                 //save closest node
       else {if (d2<best){best=d2;ibest=i;}}
    }

   for (int i=0;i<lay2n;i++)
   {
       float act=0;float ty=0;
       for (int k=0;k<lay1n;k++)
       {
           float a=outn[i].wgt[k]*hidn[k].out;
           act=act+a;                           //weighted activations sum
           ty=ty+hidn[k].out;                   //activations sum
       }
       if (ty>0) {outn[i].out=(*frw2)(act/ty);} //normalized activation (Sugeno fuzzy system)
       else outn[i].out=0;
       outn[i].buff=ty;                         //save fuzzy activations sum (for learning phase)
   }
   for (int i=0;i<dou;i++) out[i]=outn[i].out;
}



float NNfuzzy::learn(float inp[],int diminp,float train[],int dimtrain)
{
   int din=imin(diminp,lay0n);
   int dou=imin(dimtrain,lay2n);
   float out[lay2n];
   float errq=0;
   float errc=1-selfc;

   forw(inp,diminp,out,lay2n);

   for (int i=0;i<dou;i++)
    {
        float diff=out[i]-train[i];
        errq=errq+(diff*diff);
        float erri=-0.5*diff;
        erri=erri*(*learn2)(out[i]);
        float errk;
        float ty=outn[i].buff; // recall fuzzy activations sum
        for (int k=0;k<lay1n;k++)
        {
           if (ty>0){errk=EPS * erri * (outn[i].wgt[k] - outn[i].out)/ty;} //dz/dy= (w-z)/S(y))
           else errk=0;
           hidn[k].err=hidn[k].err + errk;
           float dw;
           if (ty>0) {dw=EPS * erri *(hidn[k].out) / ty;} //dz/dw= (S(w*y)/S(y)
           else dw=0;
           outn[i].wgt[k]=outn[i].wgt[k]+dw;
        }
    }

    for (int i=0;i<lay1n;i++)
    {
        float erri=hidn[i].err;
        float dc=0,ida,idb,ia,ib,dif;
        float c,x;

        for (int k=0;k<lay0n;k++) //for every component (dimension)
        {
           c=hidn[i].ctr[k];
           ia=1/hidn[i].wga[k];
           ib=1/hidn[i].wgb[k];
           x=inp[k];
           dif=fabs(x-c);
           ida=0;idb=0;
           if(i==ibest)                             //only best node correction
           {
               dc=selfc*EPS*(x-c);                  //self organize fuzzy rules by input
//               if (x<c) {ida=selfc * 0.01 * EPS * (dif-ia);}
//               else     {idb=selfc * 0.01 * EPS * (dif-ib);}
               if (x<c) {ida=selfc * EPS * (dif-0.25*ia);}
               else     {idb=selfc * EPS * (dif-0.25*ib);}

               if ((hidn[i].buff==k)&(hidn[i].out>0)) //self organize fuzzy rules by output error
               {               //just if is the minimum activation component and activation is >0
                   if (x<c)
                   {
                     dc=dc-EPS*errc*erri*hidn[i].wga[k];
                     ida=ida+EPS*errc*erri*(x-c)/(ia*ia);
                   }
                   else
                   {
                     dc=dc+EPS*errc*erri*hidn[i].wgb[k];
                     idb=idb+EPS*errc*erri*(c-x)/(ib*ib);
                   }
               }
           }
           else {dc=selfc*EPS*(x-c)*(0.1/lay1n);} //correction for other nodes (useful if no one node reacts)

           ia=ia+ida;ia=fmax(0.001,ia);
           ib=ib+idb;ib=fmax(0.001,ib);
           hidn[i].ctr[k]=c+dc;
           hidn[i].wga[k]=1/ia;
           hidn[i].wgb[k]=1/ib;
         }
    }

    errq=errq/lay2n;
    if(AUTOEPS)EPS=errq*WAUTOEPS;
    return errq;
}

#ifdef ARDUINONNET
#include <ARDUINO.h>
void NNfuzzy::print()
{
    Serial.print("L0 ");Serial.print(lay0n);Serial.println();
    Serial.print("L1 ");Serial.print(lay1n);Serial.print(" ");Serial.print(ty1);Serial.println();
    for (int i=0;i<lay1n;i++)
    {
        Serial.print("HLW");Serial.print(i);Serial.print(" ");
        for (int j=0;j<lay0n;j++)
        {Serial.print(hidn[i].wga[j],4);Serial.print(" ");}
        Serial.println();
    }
    Serial.print("L2 ");Serial.print(lay2n);Serial.print(" ");Serial.print(ty2);Serial.println();
    for (int i=0;i<lay2n;i++)
    {
        Serial.print("OLW");Serial.print(i);Serial.print(" ");
        for (int j=0;j<lay1n;j++)
        {Serial.print(outn[i].wgt[j],4);Serial.print(" ");}
        Serial.println();
    }
}

#else

void NNfuzzy::print()
{
    outdef(stdout,false);
}

void NNfuzzy::save(char* filename)
{
    FILE* fp;
    fp=fopen(filename,"w");
    if (fp==NULL) {printf("Can't open file: %s\n",filename);return;}
    outdef(fp,false);
}

void NNfuzzy::savexardu(char* filename)
{
    FILE* fp;
    fp=fopen(filename,"w");
    if (fp==NULL) {printf("Can't open file: %s\n",filename);return;}
    outdef(fp,true);
}

void NNfuzzy::outdef(FILE* fp,bool ardu)
{
    char q[3]="";char pc[3]="";
    if (ardu){strcpy(q,"\"");strcpy(pc,";");}
    fprintf(fp,"%sL0 %d %s\n",q,lay0n,q);
    fprintf(fp,"%sL1 %d %s %s\n",q,lay1n,ty1,q);

    if (frw1==Fuzzyfrw){
    for (int i=0;i<lay1n;i++)
    {
        fprintf (fp,"%sFCT%d ",q,i);
        for (int j=0;j<lay0n;j++)
        {fprintf(fp,"%6.4f ",hidn[i].ctr[j]);}
        fprintf(fp,"%s\n",q);
    }
    for (int i=0;i<lay1n;i++)
    {
        fprintf (fp,"%sFWA%d ",q,i);
        for (int j=0;j<lay0n;j++)
        {fprintf(fp,"%6.4f ",hidn[i].wga[j]);}
        fprintf(fp,"%s\n",q);
    }
    for (int i=0;i<lay1n;i++)
    {
        fprintf (fp,"%sFWB%d ",q,i);
        for (int j=0;j<lay0n;j++)
        {fprintf(fp,"%6.4f ",hidn[i].wgb[j]);}
        fprintf(fp,"%s\n",q);
    }}
    else{
    for (int i=0;i<lay1n;i++)
    {
        fprintf (fp,"%sHLW%d ",q,i);
        for (int j=0;j<lay0n;j++)
        {fprintf(fp,"%6.4f ",hidn[i].wga[j]);}
        fprintf(fp,"%s\n",q);
    }}

    fprintf(fp,"%sL2 %d %s %s\n",q,lay2n,ty2,q);
    for (int i=0;i<lay2n;i++)
    {
        fprintf (fp,"%sOLW%d ",q,i);
        for (int j=0;j<lay1n;j++)
        {fprintf(fp,"%6.4f ",outn[i].wgt[j]);}
        fprintf(fp,"%s\n",q);
    }
    fprintf(fp,"%s",pc);
    if (fp!=stdout) fclose(fp);
}

NNfuzzy::NNfuzzy(const char* filename)
{
    FILE* fp;
    fp=fopen(filename,"r");
    if (fp==NULL) {printf("Can't open file: %s\n",filename);}
    char token[10];
    int err=0;
    state=0;cnti=0;cntj=0;
    while (fscanf(fp,"%s",token)>0)
        {err=decode(token);if (err<0) return ;}
    return ;
}

#endif // NOARDUINO

NNfuzzy::NNfuzzy(char netdef[])
{
    char token[10];
    int err=0;
    state=0;cnti=0;cntj=0;
    int p=0;
    int n=0;
    while (p<strlen(netdef))
       {sscanf(&netdef[p],"%s%*[' ']%n",token,&n);
        p=p+n;
        err=decode(token);if (err<0) return ;}
    return ;
}


int NNfuzzy::readval(char* token)
{
    switch (state)
    {
       case 1 : lay0n=atoi(token);break;
       case 2 : lay1n=atoi(token);hidn=new Lhid[lay1n];state=8;break;
       case 3 : lay2n=atoi(token);outn=new Lout[lay2n];state=9;break;
       case 4 : cnti=atoi(&token[3]);hidn[cnti].wga=new float[lay0n];cntj=0;state=6;break;
       case 5 : cnti=atoi(&token[3]);outn[cnti].wgt=new float[lay1n];cntj=0;state=7;break;
       case 6 : hidn[cnti].wga[cntj]=atof(token);cntj++;break;
       case 7 : outn[cnti].wgt[cntj]=atof(token);cntj++;break;
       case 8 : decodeType1(token);break;
       case 9 : decodeType2(token);break;
       case 10 : cnti=atoi(&token[3]);hidn[cnti].ctr=new float[lay0n];cntj=0;state=11;break;
       case 11 : hidn[cnti].ctr[cntj]=atof(token);cntj++;break;
       case 12 : cnti=atoi(&token[3]);hidn[cnti].wgb=new float[lay0n];cntj=0;state=13;break;
       case 13 : hidn[cnti].wgb[cntj]=atof(token);cntj++;break;
    }
    return 0;
}

int NNfuzzy::decode(char* token)
{
    if (strncasecmp(token,"L0",2)==0) {state=1;return 0;}
    if (strncasecmp(token,"L1",2)==0) {state=2;return 0;}
    if (strncasecmp(token,"L2",2)==0) {state=3;return 0;}
    if (strncasecmp(token,"FWA",3)==0) {state=4;readval(token);return 0;}
    if (strncasecmp(token,"OLW",3)==0) {state=5;readval(token);return 0;}
    if (strncasecmp(token,"FCT",3)==0) {state=10;readval(token);return 0;}
    if (strncasecmp(token,"FWB",3)==0) {state=12;readval(token);return 0;}
    return readval(token);
}

void NNfuzzy::getHiddenOut(float out[],int dimout)
{
    int k=imin(lay1n,dimout);
    for (int i=0;i<k;i++)out[i]=hidn[i].out;
}

void NNfuzzy::getWeightsL1fromL0(int nodeL1,float w[],int dimw)
{
    int n=imin(nodeL1,lay1n-1);
    int k=imin(dimw,lay0n);
    for (int i=0;i<k;i++) w[i]=hidn[n].wga[i];
}

void NNfuzzy::getWeightsL2fromL1(int nodeL2,float w[],int dimw)
{
    int n=imin(nodeL2,lay2n-1);
    int k=imin(dimw,lay1n);
    for (int i=0;i<k;i++) w[i]=outn[n].wgt[i];
}

void NNfuzzy::setWeightsL2fromL1(int nodeL2,float w[],int dimw)
{
    int n=imin(nodeL2,lay2n-1);
    int k=imin(dimw,lay1n);
    for (int i=0;i<k;i++) outn[n].wgt[i]=w[i];
}

void NNfuzzy::getFuzzyCtr(int node,float c[],int dimc)
{
    for (int i=0;i<dimc;i++) c[i]=0;
    if(frw1!=Fuzzyfrw) return;
    int n=imin(node,lay1n-1);
    int k=imin(dimc,lay0n);
    for (int i=0;i<k;i++) c[i]=hidn[n].ctr[i];
}
void NNfuzzy::getFuzzyWa(int node,float wa[],int dimwa)
{
    for (int i=0;i<dimwa;i++) wa[i]=0;
    if(frw1!=Fuzzyfrw) return;
    getWeightsL1fromL0(node,wa,dimwa);
}
void NNfuzzy::getFuzzyWb(int node,float wb[],int dimwb)
{
    for (int i=0;i<dimwb;i++) wb[i]=0;
    if(frw1!=Fuzzyfrw) return;
    int n=imin(node,lay1n-1);
    int k=imin(dimwb,lay0n);
    for (int i=0;i<k;i++) wb[i]=hidn[n].wgb[i];
}

float NNfuzzy::getFuzzyCtr(int node,int from){return hidn[node].ctr[from];}
float NNfuzzy::getFuzzyWa(int node,int from){return hidn[node].wga[from];}
float NNfuzzy::getFuzzyWb(int node,int from){return hidn[node].wgb[from];}
float NNfuzzy::getWeightOut(int node,int from){return outn[node].wgt[from];}

int NNfuzzy::getNodesNum(int layer)
{
    switch (layer)
    {
        case 0: return lay0n;
        case 1: return lay1n;
        case 2: return lay2n;
    }
}

/*********************************************************************/
#define NRELU 0.1


float Fuzzyfrw(float x){return x;}
float Fuzzylrn(float y){return 1;}

float DeFuzzyfrw(float x){return x;}
float DeFuzzylrn(float y){return 1;}

float DeFzTnhfrw(float x){float a=exp(x);float b=exp(-x);return (a-b)/(a+b);}
float DeFzTnhlrn(float y){return 1-(y*y);}

float DeFzSigfrw(float x){return 1/(1+exp(10*(0.5-x)));}
float DeFzSiglrn(float y){return 10*y*(1-y);}

typedef float (*pf)(float x);

void decodefun(const char* ty,pf &fa,pf &fb)
{
       if (strncasecmp(ty,"NodeFuzzy",9)==0) {fa=Fuzzyfrw;fb=Fuzzylrn;}
       if (strncasecmp(ty,"NodeDeFuz",9)==0) {fa=DeFuzzyfrw;fb=DeFuzzylrn;}
       if (strncasecmp(ty,"NodeDFTnh",9)==0) {fa=DeFzTnhfrw;fb=DeFzTnhlrn;}
       if (strncasecmp(ty,"NodeDFSig",9)==0) {fa=DeFzSigfrw;fb=DeFzSiglrn;}
}


void NNfuzzy::decodeType1(const char* ty)
{
    decodefun(ty,frw1,learn1);
    strncpy(ty1,ty,20);
}

void NNfuzzy::decodeType2(const char* ty)
{
    decodefun(ty,frw2,learn2);
    strncpy(ty2,ty,20);
}
