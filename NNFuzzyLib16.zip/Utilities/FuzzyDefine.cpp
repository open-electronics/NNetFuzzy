#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <iostream>

using namespace std;

char rec[257];
char* tok[100];



int ninp=0;
int nout=0;


typedef struct
{
    char name[30];
    float *val;
}result;

typedef struct
{
    int nmsf;
    struct ms
    {
      char name[30];
      float val;
      float a;
      float b;
    }*msf;
} inpset;

typedef struct
{
    int index;
    int msind;
} cond;

typedef struct
{
    cond *cnd;
    result *r;
} rule;

inpset* inp;
result* outc[100];
rule*  rules[100];

int noutc=0;
int nrules=0;

void readfile(char* filename);
int tokenize(char* rec,char* p[],int dimp);
void decoderec(char* tok[],int ntk);
void error(char* mess);
void testread();
int compare(const void* a,const void* b);
void completeset(inpset iset[],int nmf);
int serset(char* name,int ind);
result* seroutc(char* name);
void makeNet(FILE* fd,bool quote);
void help();

int main(int argc, char* argv[])
{
    char filename[80];
    filename[0]=0;
    printf("Read Fuzzy definition from file and make a NNfuzzy net\n");
    printf("  Two files are created:\n");
    printf("  1 with name=namefile(without extension)+\"Net.txt\", for net by file\n");
    printf("  2 with name=namefile(without extension)+\"Net-quote.txt\", for net by string\n");
    if (argc<2) {printf("Insert fuzzy definition file name (or ? for help): ");scanf("%s",filename);}
    else strcpy(filename,argv[1]);
    if (filename[0]=='?') {help();return 0;}
    char outfile1[80];
    strcpy(outfile1,filename);
    strtok(outfile1,".");
    strcat(outfile1,"Net.txt");
    char outfile2[80];
    strcpy(outfile2,filename);
    strtok(outfile2,".");
    strcat(outfile2,"Net-quote.txt");
    FILE* fo1=fopen(outfile1,"w");
    FILE* fo2=fopen(outfile2,"w");

    printf("Open file %s \n",filename);
    readfile(filename);
    testread();
    printf("\n***** NNfuzzy definition *****\n");
    makeNet(stdout,true);
    makeNet(fo1,false);
    makeNet(fo2,true);

    return 0;
}

void readfile(char* filename)
{
    FILE* fin=fopen(filename,"r");
    if (fin==NULL) {printf("Can't open file %s\n",filename);exit(0);}
    char* p;
    int ntk;
    while(true)
    {
      p=fgets(rec,256,fin);
      if (p==NULL) break;
      ntk=tokenize(rec,tok,100);
      if (ntk>0) decoderec(tok,ntk);
    }
}

int tokenize(char* rec,char* p[],int dimp)
{
    int i=-1;
    int maxi=dimp-1;
    char* token = strtok(rec, " =\n");
    while (token)
    {
      if (token[0]=='/') break;
      i++;
      if (i>maxi) {i=maxi;break;}
      p[i]=token;
      token = strtok(NULL, " =\n");
    }
    return ++i;
}

void decoderec(char* tok[],int ntk)
{
    if (strcmp(tok[0],"input")==0){ninp=atoi(tok[1]);inp=new inpset[ninp];return;}
    if (strcmp(tok[0],"output")==0) {nout=atoi(tok[1]);return;}
    if ((ninp==0)|(nout==0)) error("Format error: No inp/out dimensions!");
    if (strcmp(tok[0],"inpfuzzyset")==0)
    {
       int index=atoi(tok[1]);
       int nmf=(ntk-2)/2;
       inpset* iset=new inpset;
       (*iset).nmsf=nmf;(*iset).msf=new inpset::ms[nmf];
       int cmf=0;
       for (int i=2;i<ntk;i=i+2)
       {
          strcpy((*iset).msf[cmf].name,tok[i]);
          (*iset).msf[cmf].val=atof(tok[i+1]);
          cmf++;
       }
       inp[index]=*iset;
       qsort(inp[index].msf,nmf,sizeof(inpset::ms),compare);
       completeset(&inp[index],nmf);
       return;
    }
    if (strcmp(tok[0],"outclass")==0)
    {
       noutc++;
       result *r=new result;
       strcpy((*r).name,tok[1]);
       (*r).val=new float[nout];
       for (int k=0;k<nout;k++)
       (*r).val[k]=atof(tok[2+k]);
       outc[noutc-1]=r;
       return;
    }
    if (strcmp(tok[0],"if")==0)
    {
        nrules++;
        rule *r=new rule;
        (*r).cnd= new cond[ninp];
        int tk=0;int nc=0;
        while(tk<ntk)
        {
            tk++;
            if (strcmp(tok[tk],"and")==0) continue;
            if (strcmp(tok[tk],"then")==0) break;
            int ind=atoi(tok[tk]);
            tk++;
            int iset=serset(tok[tk],ind);
            (*r).cnd[nc].index=ind;
            (*r).cnd[nc].msind=iset;
            nc++;
        }
        result* res=seroutc(tok[tk+1]);
        (*r).r=res;
        rules[nrules-1]=r;
    }
}

int compare(const void * a,const void * b)
{
    inpset::ms *msa=(inpset::ms *)a;
    inpset::ms *msb=(inpset::ms *)b;
    if (msa->val< msb->val) return -1; else return 1;
}

void completeset(inpset* iset,int nmf)
{
    for(int i=0;i<nmf;i++)
    {
        if (i==0) (*iset).msf[i].a=0.1;
        else (*iset).msf[i].a=1/((*iset).msf[i].val-(*iset).msf[i-1].val);
        if (i==nmf-1) (*iset).msf[i].b=0.1;
        else (*iset).msf[i].b=1/((*iset).msf[i+1].val-(*iset).msf[i].val);
    }
}

int serset(char* name,int ind)
{
    for (int i=0;i<inp[ind].nmsf;i++)
    {
       if (strcmp(name,inp[ind].msf[i].name)==0) return i;
    }
    return 0;
}

result* seroutc(char* name)
{
    for (int i=0;i<noutc;i++)
    {
        result* res=outc[i];
        if (strcmp((*res).name,name)==0) return res;
    }
    return NULL;
}

void testread()
{
    printf("inp: %d out: %d\n",ninp,nout);
    for (int i=0;i<ninp;i++)
    {
        int tk=inp[i].nmsf;
        printf("inp%d %dset: ",i,tk);
        for (int k=0;k<tk;k++) printf("%s=%4.3f ",inp[i].msf[k].name,inp[i].msf[k].val);
        printf("\n");
        for (int k=0;k<tk;k++)
        {
            float a=inp[i].msf[k].a;
            float b=inp[i].msf[k].b;
            float c=inp[i].msf[k].val;
            printf("%4.3f<%4.3f>%4.3f ",(c-1/a),c,(c+1/b));
        }
        printf("\n");
    }
    for (int i=0;i<noutc;i++)
    {
        printf("outclass %s : ",(*outc[i]).name);
        for (int k=0;k<nout;k++) printf("%4.3f ",(*outc[i]).val[k]);
        printf("\n");
    }
    for (int i=0;i<nrules;i++)
    {
        rule* r=rules[i];
        printf("R%d: if [ ",i);
        for (int c=0;c<ninp;c++)
        {
            int in=(*r).cnd[c].index;
            int msind=(*r).cnd[c].msind;
            inpset *is=&inp[in];
            char* name=(*is).msf[msind].name;
            float v=(*is).msf[msind].val;
            printf("%d=%s(%4.3f), ",in,name,v);
        }
        printf("] -> %s\n",(*r).r->name);
    }
}

char defrec[257];

void makeNet(FILE* fd,bool quote)
{
  char* q="";
  if(quote)q="\"";
  sprintf(defrec,"%sL0 %d %s\n",q,ninp,q);fprintf(fd,"%s",defrec);
  sprintf(defrec,"%sL1 %d NodeFuzzy %s\n",q,nrules,q);fprintf(fd,"%s",defrec);
  for (int i=0;i<nrules;i++)
  {
     rule* r=rules[i];
     int p=sprintf(defrec,"%sFCT%d ",q,i);
     for (int c=0;c<ninp;c++)
     {
       int in=(*r).cnd[c].index;
       int msind=(*r).cnd[c].msind;
       inpset *is=&inp[in];
       float v=(*is).msf[msind].val;
       p=p+sprintf(&defrec[p],"%4.3f ",v);
     }
     sprintf(&defrec[p],"%s\n",q);
     fprintf(fd,"%s",defrec);
  }
  for (int i=0;i<nrules;i++)
  {
     rule* r=rules[i];
     int p=sprintf(defrec,"%sFWA%d ",q,i);
     for (int c=0;c<ninp;c++)
     {
       int in=(*r).cnd[c].index;
       int msind=(*r).cnd[c].msind;
       inpset *is=&inp[in];
       float v=(*is).msf[msind].a;
       p=p+sprintf(&defrec[p],"%4.3f ",v);
     }
     sprintf(&defrec[p],"%s\n",q);
     fprintf(fd,"%s",defrec);
  }
  for (int i=0;i<nrules;i++)
  {
     rule* r=rules[i];
     int p=sprintf(defrec,"%sFWB%d ",q,i);
     for (int c=0;c<ninp;c++)
     {
       int in=(*r).cnd[c].index;
       int msind=(*r).cnd[c].msind;
       inpset *is=&inp[in];
       float v=(*is).msf[msind].b;
       p=p+sprintf(&defrec[p],"%4.3f ",v);
     }
     sprintf(&defrec[p],"%s\n",q);
     fprintf(fd,"%s",defrec);
  }
  sprintf(defrec,"%sL2 %d NodeDFTnh %s\n",q,nout,q);fprintf(fd,"%s",defrec);
  for (int i=0;i<nout;i++)
  {
     int p=sprintf(defrec,"%sOLW%d ",q,i);
     for (int k=0;k<nrules;k++)
     {
         rule *r=rules[k];
         float v=(*r).r->val[i];
         p=p+sprintf(&defrec[p],"%4.3f ",v);
     }
     sprintf(&defrec[p],"%s\n",q);
     fprintf(fd,"%s",defrec);
  }
}

void error(char* mess)
{
    printf("%s\n",mess);
    exit(-1);
}

void printExample()
{
    cout <<"    /******** Fuzzy definition **********/ \n"
"input 2 \n"
"output 2 \n"
"inpfuzzyset 0  A=0.0 B=0.5  C=0.8 // set for dimension 0 A:far B:near C:very near\n"
"inpfuzzyset 1  A=0.0 B=0.5  C=0.8 // set for dimension 1 A:far B:near C:very near\n"
"outclass AAS 1.0 1.0              // ahead fast straight\n"
"outclass AAL 0.6 1.0              // ahead fast and left rotate\n"
"outclass AAR 1.0 0.6              // ahead fast and right rotate\n"
"outclass AA 0.6 0.6               // ahead medium\n"
"outclass AL 0.4 0.6               // ahead medium and left rotate\n"
"outclass AR 0.6 0.4               // ahead medium and right rotate\n"
"outclass BL -0.6 -0.2             // back and left rotate\n"
"/** Rules **/\n"
"if 0=A and 1=A then AAS\n"
"if 0=A and 1=B then AAL\n"
"if 0=B and 1=A then AAR\n"
"if 0=B and 1=B then AA\n"
"if 0=B and 1=C then AL\n"
"if 0=C and 1=B then AR\n"
"if 0=C and 1=C then BL\n";
}

void help()
{
    printf("\nThe file has to contain the fuzzy definition in this terms:\n");
    printf("   input dimensions  ex.: input 2\n");
    printf("   output dimensions ex.: output 2\n");
    printf("   fuzzy set for each input dimension with its name and value (just center)\n");
    printf("        ex.: inpfuzzyset 0  A=0.0 B=0.5  C=0.8\n");
    printf("   out class names linked to output values (for each dim.) used as consequent of rule\n");
    printf("        ex.: outclass AAS 1.0 1.0 \n");
    printf("   rules ex.: if 0=A and 1=A then AAS\n");
    printf("\n NB comments (starting with '/') are ignored\n");
    printf("\n Example: \n");
    printExample();
}

