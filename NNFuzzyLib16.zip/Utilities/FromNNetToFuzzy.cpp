#include "../../NNetFzLib16Ardu/NNetFuzzy.h"

#include <iostream>

using namespace std;


typedef struct mbf
{
    char name[10];
    float c;
    float a;
    float b;
};

typedef struct iset
    {
       int nmf;
       mbf *mf;
    };

typedef struct oclass
    {
        char name[10];
    };

void translate(NNfuzzy* net,FILE* fd);
char* searchname(mbf *mf,int dim,float v);
int checkunic(float a[],int dim,float v);
int compare(const void * a,const void * b);
void printMbf(int ninp,iset is[],char* filename );

int main(int argc, char* argv[])
{
    char filename[80];
    filename[0]=0;
    printf("Read NNfuzzy from file and generate equivalent Fuzzy description\n");
    printf("Fuzzy description is saved as file with name extracted from NNfuzzy file name:\n ");
    printf("    name: namefilenet (without exansion)+\"-FzDescr.txt\"\n");
    if (argc<2) {printf("Insert file name containing NNfuzzy net definition : ");scanf("%s",filename);}
    else strcpy(filename,argv[1]);
    if (strlen(filename)<2) return 0;

    FILE* fin=fopen(filename,"r");
    if (fin==NULL) {printf("Can't open file %s\n",filename);return 0;}
    fclose(fin);

    char outfile1[80];
    strcpy(outfile1,filename);
    strtok(outfile1,".");
    strcat(outfile1,"-FzDescr.txt");
    FILE* fo1=fopen(outfile1,"w");

    NNfuzzy* net=new NNfuzzy((const char*) filename);

    translate(net,stdout);
    translate(net,fo1);



    return 0;
}

void translate(NNfuzzy* net,FILE* fd)
{
    int ninp=(*net).getNodesNum(0);
    int nout=(*net).getNodesNum(2);
    int nr=(*net).getNodesNum(1);

    iset is[ninp];
    oclass oc[nr];

    fprintf(fd,"/****** Fuzzy description ******/\n");

    fprintf(fd,"input %d\n",ninp);
    fprintf(fd,"output %d\n",nout);

    for (int i=0;i<ninp;i++)
    {
      float vs[nr];float a[nr];float b[nr];int cn=0;
      for (int k=0;k<nr;k++)
      {
          float kc=(*net).getFuzzyCtr(k,i);
          float ka=(*net).getFuzzyWa(k,i);
          float kb=(*net).getFuzzyWb(k,i);
          if (k>0) {int n=checkunic(vs,cn,kc);
                      if(n<0)
                      {vs[cn]=kc;a[cn]=ka;b[cn]=kb;cn++;}
                      else;
                    //  {vs[cn]=vs[n];a[cn]=a[n];b[cn]=b[n];cn++;}
          }
          else {vs[cn]=kc;a[cn]=ka;b[cn]=kb;cn++;}
      }
      is[i].nmf=cn;
      is[i].mf=new mbf[cn];
      for (int k=0;k<cn;k++){is[i].mf[k].c=vs[k];is[i].mf[k].a=a[k];is[i].mf[k].b=b[k];}
      qsort(is[i].mf,cn,sizeof(mbf),compare);
      for (int k=0;k<cn;k++){sprintf(is[i].mf[k].name,"A%d",k);}
    }

    for (int i=0;i<ninp;i++)
    {
      fprintf(fd,"inpfuzzyset %d ",i);
      for (int k=0;k<is[i].nmf;k++)
      {fprintf(fd,"%s=%4.3f ",is[i].mf[k].name,is[i].mf[k].c);}
      fprintf(fd,"\n");
      for (int k=0;k<is[i].nmf;k++)
      {mbf m=is[i].mf[k];float c=m.c;float xa=c-1/m.a;float xb=c+1/m.b;
       fprintf(fd,"/* %s : %4.3f<%4.3f>%4.3f */\n",m.name,xa,c,xb);}
    }
    for (int i=0;i<nr;i++)
    {
      sprintf(oc[i].name,"B%d",i);
      fprintf(fd,"outclass %s ",oc[i].name);
      for (int k=0;k<nout;k++)
      {
          float v=(*net).getWeightOut(k,i);
          fprintf(fd,"%4.3f ",v);
      }
      fprintf(fd,"\n");
    }

    fprintf(fd,"/***** Rules *****/\n");

    for (int i=0;i<nr;i++)
    {
      fprintf(fd,"if ");
      for (int k=0;k<ninp;k++)
      {
          float c=(*net).getFuzzyCtr(i,k);
          char* name=searchname(is[k].mf,is[k].nmf,c);
          fprintf(fd,"%d=%s ",k,name);
          if(k<ninp-1) fprintf(fd," and ");
      }
      fprintf(fd," then %s\n",oc[i].name);
    }

    if (fd==stdout) printMbf(ninp,is,"Membershipfun");
}

char* searchname(mbf *m,int dim,float v)
{
    char* name=NULL;
    int iv=round(v*100);
    int ic=0;
    for (int n=0;n<dim;n++)
        {ic=round(m[n].c*100);if (ic==iv) {name=m[n].name;break;}}
    return name;
}

int checkunic(float a[],int dim,float v)
{
    for (int i=0;i<dim;i++)
    {
        int ia=round(a[i]*100);
        int iv=round(v*100);
        if (ia==iv) return i;
    }
    return -1;
}

int compare(const void * a,const void * b)
{
    mbf *msa=(mbf *)a;
    mbf *msb=(mbf *)b;
    if (msa->c <= msb->c) return -1; else return 1;
}

void printMbf(int ninp,iset is[],char* filename )
{
    char fname[64];
    for (int i=0;i<ninp;i++)
    {
       sprintf(fname,"%s-A%d",filename,i);
       FILE* fp=fopen(fname,"w");
       for (int k=0;k<is[i].nmf;k++)
       {
         mbf m=is[i].mf[k];float c=m.c;float xa=c-1/m.a;float xb=c+1/m.b;
         fprintf(fp,"0 %4.3f\n1 %4.3f\n0 %4.3f\n\n",xa,c,xb);
       }
       fclose(fp);
     }

}
